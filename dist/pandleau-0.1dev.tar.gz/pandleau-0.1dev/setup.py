from distutils.core import setup

setup(name='pandleau',
      version='0.1dev',
      description='A quick and easy way to convert a Pandas DataFrame to a Tableau extract.',
      long_description=open('README.md').read(),
      author='Benjamin Wiley',
      author_email='bewi7122@colorado.edu',
      url='https://github.com/bwiley1/pandleau',
      download_url='https://github.com/bwiley1/pandleau/archive/1.0.0.tar.gz',
      py_modules=['pandleau'],
      license='MIT',
      zip_safe=False,
      keywords='tableau pandas extract tde',
      classifiers=['Programming Language :: Python',
                   'Topic :: Software Development :: Libraries :: Python Modules'])